# SURVIVORS - Complete Setup Guide

## ⚡ Quick Setup (5 minutes)

### Step 1: Install Node.js
Download and install Node.js 18+ from https://nodejs.org/

Verify installation:
```bash
node --version  # Should be v18 or higher
npm --version   # Should be 8+
```

### Step 2: Extract Project Files
Extract the survivors-setup folder to your desired location.

### Step 3: Install Dependencies
Open terminal in the project directory and run:
```bash
npm install
```

This will install:
- Next.js 14
- React 18
- Framer Motion 10
- Tailwind CSS 3
- TypeScript 5

### Step 4: Start Development Server
```bash
npm run dev
```

You'll see:
```
> ready - started server on 0.0.0.0:3000, url: http://localhost:3000
```

### Step 5: Open in Browser
Visit: **http://localhost:3000**

You should see the animated SURVIVORS landing page with live storm countdown!

---

## 📁 What's Included

### Core Files

#### Pages (`pages/`)
- `_app.tsx` - App wrapper with GameProvider
- `_document.tsx` - HTML document setup
- `index.tsx` - Main home page (all sections + modals)

#### Components (`components/`)
- `Hero.tsx` - Landing section with animated stats
- `LiveStormPanel.tsx` - Storm countdown & elimination effects
- `SurvivorFeed.tsx` - Leaderboard with top holders
- `JackpotSection.tsx` - Mechanics explanation & projections
- `RulesSection.tsx` - Game rules & FAQs
- `ActivityFeed.tsx` - Real-time event feed
- `Footer.tsx` - Footer with links
- `ParticleBackground.tsx` - Animated particle effects

#### Game Logic (`utils/` & `context/`)
- `mockData.ts` - Survivor generation, game logic, calculations
- `animations.ts` - Framer Motion animation variants
- `GameContext.tsx` - Global state management (survivors, jackpot, storms)

#### Styling
- `styles/globals.css` - Global styles, animations, theme
- `tailwind.config.js` - Tailwind theme configuration

#### Config
- `next.config.js` - Next.js settings
- `postcss.config.js` - CSS processing
- `package.json` - Dependencies & scripts

---

## 🎮 Testing the Game

### Automatic Features (No Setup Needed)
✅ Storm countdown - Every 60 seconds
✅ Wallet elimination - 5-15% per storm  
✅ Jackpot growth - 5% of buy amounts
✅ Activity log - Real-time events
✅ Leaderboard - Top 10 holders
✅ Extra lives - Based on holdings

### Test the Buy Modal
1. Click "Buy To Enter" button
2. Adjust amount slider or enter custom amount
3. Click "Enter Game"
4. New survivor appears in leaderboard
5. Check activity feed for event

### Test Storm Effects
1. Watch the countdown timer
2. When it reaches 0, a storm strikes
3. Random wallets are eliminated
4. Lightning effects and glitch animation play
5. Activity feed shows elimination events

### Check Live Stats
- **Survivors Alive** - Decreases with each storm
- **Current Jackpot** - Increases with each buy
- **Next Storm In** - 60-second countdown
- **Eliminated** - Total wallets knocked out

---

## 🚀 Build for Production

### Generate Optimized Build
```bash
npm run build
```

Output: `.next/` folder with optimized code

### Test Production Build
```bash
npm start
```

Runs on http://localhost:3000 with production optimizations

### Build Size Analysis
```bash
npm run build
# Check .next/static/chunks for bundle sizes
```

---

## 🌐 Deploy to Vercel

### Option 1: Vercel CLI (Recommended)
```bash
# Install Vercel CLI globally (one time)
npm install -g vercel

# Deploy from project directory
vercel

# Follow prompts:
# 1. Confirm project name
# 2. Link to Git (optional)
# 3. Framework detected: Next.js ✓
# 4. Deploy!
```

### Option 2: GitHub + Vercel
1. Push code to GitHub
2. Go to https://vercel.com
3. Click "New Project"
4. Import your GitHub repository
5. Vercel auto-detects Next.js
6. Click Deploy
7. Auto-deploys on future pushes

### Option 3: Manual Deployment
```bash
npm run build
# Upload .next folder + node_modules to your server
npm start
```

---

## 🔧 Customization Guide

### Change Game Parameters

Edit `context/GameContext.tsx`:

```typescript
// Change storm frequency (in seconds)
const interval = setInterval(() => {
  setStormCountdown((prev) => {
    if (prev <= 1) {
      // Change 60 to your desired interval
      return 60;
    }
    return prev - 1;
  });
}, 1000);
```

Edit `utils/mockData.ts`:

```typescript
// Change elimination percentage
const toEliminate = Math.floor(aliveSurvivors.length * (0.05 + Math.random() * 0.10));
//                                                       ^^^^ min ^^^^ max
// Current: 5-15%, change to 10-20% by adjusting 0.05 and 0.15
```

### Change Colors

Edit `tailwind.config.js`:

```javascript
colors: {
  'void': '#0a0e27',        // Primary background
  'cyan': '#00d9ff',        // Primary accent
  'magenta': '#ff006e',     // Secondary accent
  'neon-green': '#39ff14',  // Success color
  'purple': '#7c3aed',      // Premium color
}
```

Or in `styles/globals.css`:

```css
.glow-text {
  text-shadow: 0 0 10px #00d9ff, 0 0 20px #00d9ff;
}
```

### Change Fonts

Edit `tailwind.config.js`:

```javascript
fontFamily: {
  'orbitron': ['Orbitron', 'sans-serif'],      // Headers
  'space-mono': ['Space Mono', 'monospace'],   // Data
  'inter': ['Inter', 'sans-serif'],            // Body
}
```

Import different fonts in `styles/globals.css`:

```css
@import url('https://fonts.googleapis.com/css2?family=YOUR_FONT:wght@400;700&display=swap');
```

---

## 📊 Connecting Real Data

### Step 1: Get Token Address
From Pump.fun, get your token contract address:
```
Example: 0x1234567890abcdef...
```

### Step 2: Add API Fetch Function
In `utils/mockData.ts`, add:

```typescript
export const fetchRealHolders = async (tokenAddress: string) => {
  try {
    // Option A: Use Pump.fun API
    const response = await fetch(`https://api.pump.fun/token/${tokenAddress}`);
    const data = await response.json();
    
    // Transform to Survivor format
    return data.holders.map((holder: any) => ({
      id: holder.address,
      walletAddress: holder.address,
      tokenAmount: holder.balance,
      usdValue: holder.balance * 0.0002, // Adjust price
      status: 'alive' as const,
      buyInAmount: holder.balance * 0.0002,
      timestamp: Date.now(),
      entryTime: new Date().toLocaleTimeString(),
      extraLives: holder.balance >= 50000 ? 1 : 0,
    }));
  } catch (error) {
    console.error('Failed to fetch holders:', error);
    return generateInitialSurvivors(150); // Fallback to mock data
  }
};
```

### Step 3: Update Game Context
In `context/GameContext.tsx`, modify initialization:

```typescript
useEffect(() => {
  const loadData = async () => {
    const survivors = await fetchRealHolders('TOKEN_ADDRESS');
    setGameState(prev => ({
      ...prev,
      survivors,
      totalJackpot: calculateJackpot(survivors),
    }));
  };
  
  loadData();
}, []);
```

---

## 🐛 Troubleshooting

### Issue: Port 3000 Already in Use
**Solution:**
```bash
# Use different port
npm run dev -- -p 3001
# Open: http://localhost:3001
```

### Issue: Module Not Found Error
**Solution:**
```bash
# Clear node_modules and reinstall
rm -rf node_modules package-lock.json
npm install
npm run dev
```

### Issue: Tailwind Styles Not Showing
**Solution:**
1. Clear Next.js cache: `rm -rf .next`
2. Ensure `styles/globals.css` imported in `_app.tsx`
3. Restart dev server: `npm run dev`

### Issue: Animations Not Smooth
**Solution:**
1. Open DevTools → Performance
2. Check for dropped frames
3. Reduce particle count in ParticleBackground.tsx:
```typescript
const particleCount = 50; // Reduce from 100
```

### Issue: Page Flashing on Load (Hydration Error)
**Solution:**
Already handled! We use dynamic imports in `_app.tsx`:
```typescript
const [mounted, setMounted] = useState(false);

useEffect(() => {
  setMounted(true); // Only render after hydration
}, []);

if (!mounted) return null;
```

---

## 📈 Performance Optimization

### Current Optimizations
✅ Code splitting (Next.js automatic)
✅ Image optimization (if using next/image)
✅ CSS purging (Tailwind removes unused styles)
✅ Particle scaling (responsive based on viewport)
✅ Animation frame budgeting

### Further Optimizations
```typescript
// Implement pagination for survivor list
const itemsPerPage = 20;
const [page, setPage] = useState(0);

// Lazy load components
const ActivityFeed = dynamic(() => import('./ActivityFeed'));

// Memoize expensive calculations
const memoizedLeaderboard = useMemo(() => {
  return survivors.sort(...);
}, [survivors]);
```

---

## 🔐 Security Checklist

- ✅ No private keys stored
- ✅ No environment variables exposed
- ✅ Client-side only (v1)
- ✅ No form data sent to servers
- ✅ Open-source and auditable

**Before Production:**
- [ ] Add Content Security Policy headers
- [ ] Enable HTTPS only
- [ ] Add rate limiting if backend added
- [ ] Audit smart contracts
- [ ] Test wallet security

---

## 📚 Learning Resources

### Next.js
- https://nextjs.org/docs
- https://nextjs.org/learn

### Framer Motion
- https://www.framer.com/motion/introduction/
- https://www.youtube.com/c/FramerDesign

### Tailwind CSS
- https://tailwindcss.com/docs
- https://tailwindcss.com/docs/customization

### TypeScript
- https://www.typescriptlang.org/docs/
- https://www.typescriptlang.org/play

### React
- https://react.dev
- https://react.dev/learn

---

## 🎯 Next Steps

1. ✅ Get project running locally
2. ✅ Test all features (storm, eliminations, etc.)
3. ✅ Customize colors/fonts to match your brand
4. ✅ Connect real Pump.fun data
5. ✅ Build & deploy to Vercel
6. ✅ Share with community

---

## 💬 Questions?

### Common Questions

**Q: Can I modify the game mechanics?**
A: Yes! Everything in `context/GameContext.tsx` and `utils/mockData.ts` is customizable.

**Q: How do I add Web3 wallet connection?**
A: In v2, integrate `@web3-react/core` or `wagmi` for MetaMask/Wallet Connect.

**Q: Can I deploy to other platforms?**
A: Yes! This is a Next.js app. Works on any Node.js host (AWS, Heroku, Railway, etc.)

**Q: How do I add more animations?**
A: Edit animation configs in `utils/animations.ts` and create Framer Motion variants.

**Q: Can I run this on mobile?**
A: Yes! It's fully responsive. Test with DevTools mobile emulation.

---

## 🚀 You're Ready!

Everything you need is included. The app is production-ready and can be deployed immediately.

```bash
# Your checklist:
✓ Node.js installed
✓ Dependencies installed (npm install)
✓ Dev server running (npm run dev)
✓ Open localhost:3000
✓ See SURVIVORS landing page
✓ Test features (storm, buy, rules)
✓ Customize (colors, text, mechanics)
✓ Deploy (npm run build + vercel)

// Now go launch this to the moon! 🚀
```

**Happy launching!** 🎮⚡💎
